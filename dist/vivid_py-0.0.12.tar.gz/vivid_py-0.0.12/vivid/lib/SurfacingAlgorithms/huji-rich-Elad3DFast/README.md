# huji-rich
RICH is an compressible hydrodynamic simulation on a moving mesh written in c++.
We've recently published papers explaining the [serial](http://iopscience.iop.org/0067-0049/216/2/35/) and 
[parallel](http://adsabs.harvard.edu/abs/2015ApJS..216...14S) versions of the code.
