#include "riemann_solver.hpp"

RiemannSolver::~RiemannSolver(void) {}
