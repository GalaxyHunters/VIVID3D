#include "vertex_motion.hpp"

VertexMotion::~VertexMotion(void) {}
