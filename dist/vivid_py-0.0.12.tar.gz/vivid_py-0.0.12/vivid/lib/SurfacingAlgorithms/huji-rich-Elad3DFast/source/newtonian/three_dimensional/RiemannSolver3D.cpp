#include "RiemannSolver3D.hpp"

RiemannSolver3D::~RiemannSolver3D() {}