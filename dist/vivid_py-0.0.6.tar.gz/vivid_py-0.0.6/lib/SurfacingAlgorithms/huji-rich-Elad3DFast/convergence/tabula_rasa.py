import os

os.system('rm -rf temp_*')
os.system('rm -rf */run_*')
os.system('rm l1_vs_res_*.txt')
