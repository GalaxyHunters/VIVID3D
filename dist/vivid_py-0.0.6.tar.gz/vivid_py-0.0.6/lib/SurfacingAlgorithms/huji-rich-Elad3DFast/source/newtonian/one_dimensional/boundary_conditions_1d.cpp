#include "boundary_conditions_1d.hpp"

BoundaryConditions1D::~BoundaryConditions1D(void) {}
