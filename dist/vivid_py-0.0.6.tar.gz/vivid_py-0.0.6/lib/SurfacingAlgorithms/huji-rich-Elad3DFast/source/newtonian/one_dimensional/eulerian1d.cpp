#include "eulerian1d.hpp"

double Eulerian1D::CalcVelocity
(int /*i*/, vector<double> const& /*vp*/,
 vector<Primitive> const& /*hv*/) const
{
  return 0;
}
