#include "source_term_1d.hpp"

SourceTerm1D::~SourceTerm1D(void) {}
