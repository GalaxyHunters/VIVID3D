#include "extensive_updater3d.hpp"

ExtensiveUpdater3D::~ExtensiveUpdater3D() {}