#include "equation_of_state.hpp"

EquationOfState::~EquationOfState(void) {}
