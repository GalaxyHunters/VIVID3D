#include "spatial_reconstruction1d.hpp"

SpatialReconstruction1D::~SpatialReconstruction1D(void) {}
