#include "func_1_var.hpp"

Func1Var::~Func1Var(void) {}
