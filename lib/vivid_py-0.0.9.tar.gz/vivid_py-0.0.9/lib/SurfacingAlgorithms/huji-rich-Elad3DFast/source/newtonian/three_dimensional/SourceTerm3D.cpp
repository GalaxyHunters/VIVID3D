#include "SourceTerm3D.hpp"

SourceTerm3D::~SourceTerm3D(void){}

double SourceTerm3D::SuggestInverseTimeStep(void)const
{
	return 0;
}