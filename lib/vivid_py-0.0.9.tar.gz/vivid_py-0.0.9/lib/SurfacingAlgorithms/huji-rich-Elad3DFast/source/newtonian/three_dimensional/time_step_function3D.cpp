#include "time_step_function3D.hpp"

TimeStepFunction3D::~TimeStepFunction3D(void) {}
